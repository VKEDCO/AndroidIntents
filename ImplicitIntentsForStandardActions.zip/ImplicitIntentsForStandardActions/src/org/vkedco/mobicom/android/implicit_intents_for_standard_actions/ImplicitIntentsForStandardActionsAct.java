package org.vkedco.mobicom.android.implicit_intents_for_standard_actions;

/*
 ******************************************************** 
 * implicit intents for launching activities to handle standard
 * actions.
 * 
 * bugs to vladimir dot kulyukin at gmail dot com
 ********************************************************
 */

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ImplicitIntentsForStandardActionsAct extends Activity
implements OnClickListener
{
	Button mBtnActionView = null;
	Button mBtnActionWebSearch = null;
	Button mBtnActionDial = null;
	Button mBtnActionSetWallpaper = null;
	Resources mRes = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_implicit_intents_for_standard_actions_layout);
		
		this.mBtnActionView = (Button) this.findViewById(R.id.btnActionView);
		this.mBtnActionWebSearch = (Button) this.findViewById(R.id.btnActionWebSearch);
		this.mBtnActionDial = (Button) this.findViewById(R.id.btnActionDial);
		this.mBtnActionSetWallpaper = (Button) this.findViewById(R.id.btnActionCall);
		this.mRes = getResources();
		
		this.mBtnActionView.setOnClickListener(this);
		this.mBtnActionWebSearch.setOnClickListener(this);
		this.mBtnActionDial.setOnClickListener(this);
		this.mBtnActionSetWallpaper.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.implicit_intents_for_standard_actions,
				menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		switch ( v.getId() ) {
		case R.id.btnActionView: 
			Intent iview = new Intent(Intent.ACTION_VIEW);
			iview.setData(Uri.parse(mRes.getString(R.string.action_view_url)));
			startActivity(iview);
			return;
		case R.id.btnActionWebSearch:
			Intent isearch = new Intent(Intent.ACTION_WEB_SEARCH);
			// this does not seem to matter; the search will be taken to www.google.com
			isearch.setData(Uri.parse(mRes.getString(R.string.action_web_search_url)));
			startActivity(isearch);
			return;
		case R.id.btnActionDial:
			Intent idial = new Intent(Intent.ACTION_DIAL);
			idial.setData(Uri.parse(mRes.getString(R.string.action_dial_phone_number)));
			startActivity(idial);
			return;
		case R.id.btnActionCall:
			Intent icall = new Intent(Intent.ACTION_SET_WALLPAPER);
			// no data are attached so that the empty dialer is started.
			startActivity(icall);
			return;
		}
		
	}

	

}
