/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.mobicom.android.implicit_intents_for_standard_actions;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}