package org.vkedco.mobappdev.explicit_intents_02;

/*
 * ********************************************
 * 
 * ImageDisplayerAct02.java - default activity of
 * ExplicitIntentsApp02 app. When requested to
 * run via an explicit intent from MainLauncherAct,
 * ImageDisplayerACt02 retrieves a key-value pair
 * from the intent and displays the image whose number
 * is specified by the value.
 * 
 * Bugs to vladimir dot kulyukin at gmail dot com
 * ********************************************
 */

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ImageDisplayerAct02 extends Activity {

	protected ImageView mImgView = null;
	protected TextView mTV = null;
	protected Resources mRes = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.img_displayer_act02_layout);
		
		mTV = (TextView) this.findViewById(R.id.tv_01);
		mImgView = (ImageView) this.findViewById(R.id.img_view_01);
		mImgView.setImageDrawable(null);
		mRes = getResources();

		// 1. Get the intent
		Intent i = this.getIntent();
		// 2. Check to see if it contains an integer keyed on R.string.img_id_key.
		// default to 0 if it does not.
		int img_num = i.getIntExtra(mRes.getString(R.string.img_id_key), 0);

		// 3. If it does, display it
		if (img_num > 0) {
			switch (img_num) {
			case 1:
				mImgView.setBackgroundResource(R.drawable.img_01);
				break;
			case 2:
				mImgView.setBackgroundResource(R.drawable.img_02);
				break;
			case 3:
				mImgView.setBackgroundResource(R.drawable.img_03);
				break;
			case 4:
				mImgView.setBackgroundResource(R.drawable.img_04);
				break;
			case 5:
				mImgView.setBackgroundResource(R.drawable.img_05);
				break;
			case 6:
				mImgView.setBackgroundResource(R.drawable.img_06);
				break;
			case 7:
				mImgView.setBackgroundResource(R.drawable.img_07);
				break;
			case 8:
				mImgView.setBackgroundResource(R.drawable.img_08);
				break;
			}
			// Set the text of the mTV text view to the appropriate message.
			mTV.setText(mRes.getString(R.string.img_display_msg) + " " + img_num);	
		}
	}
}
