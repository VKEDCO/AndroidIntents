package org.vkedco.mobappdev.explicit_intents_01;

/*
 * ********************************************
 * 
 * MainLauncherAct.java - main activity of
 * ExplicitIntentsApp01 app. Shows how to create an
 * explicit intent to run ImageDisplayerAct01.class.
 * 
 * Bugs to vladimir dot kulyukin at gmail dot com
 * ********************************************
 */

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainLauncherAct extends Activity {
	
	protected Button mBtnDisplay = null;
	protected Activity mThisAct = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_launcher);
        mBtnDisplay = (Button) this.findViewById(R.id.btn_display);
        mThisAct = this;
        
        mBtnDisplay.setOnClickListener(
        		new OnClickListener() {
					@Override
					public void onClick(View v) {
						// 1. Create an explicit intent
						Intent i = new Intent(mThisAct, ImageDisplayerAct01.class);
						// 2. Request Android to run it.
						startActivity(i);
					}	
        		}
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main_launcher, menu);
        return true;
    }
}
